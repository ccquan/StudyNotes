window.alert('hello world')
