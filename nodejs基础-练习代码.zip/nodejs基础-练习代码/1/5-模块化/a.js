var b = require('./b.js');
console.log('age: ' + b.age);
console.log('add: ' + b.add(2, 3))