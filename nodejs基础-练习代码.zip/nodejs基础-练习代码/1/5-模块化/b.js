exports.age = 22;
exports.add = function(x, y) {
    return x + y;
}