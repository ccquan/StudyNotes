var echo = 'hello world';
console.log(echo);